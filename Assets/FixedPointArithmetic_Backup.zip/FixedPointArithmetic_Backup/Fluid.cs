﻿// StableFluids - A GPU implementation of Jos Stam's Stable Fluids on Unity
// https://github.com/keijiro/StableFluids

using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Assertions;

namespace StableFluids
{
    public class Fluid : MonoBehaviour
    {
        #region Editable attributes

        [Header("Fluid Settings")]
        [SerializeField] private int _resolution = 512;
        [SerializeField] private float _viscosity = 1e-6f;
        [SerializeField] private float _force = 300;
        [SerializeField] private int _exponent = 200;
        [SerializeField] private Texture2D _initial = null;

        private FixedPoint _fixedViscosity = new FixedPoint();

        #endregion

        #region Internal resources

        [SerializeField, HideInInspector] private ComputeShader _compute = null;
        [SerializeField, HideInInspector] private Shader _shader = null;

        #endregion

        #region Private members

        private Material _shaderSheet = null;
        private Vector2 _previousInput = Vector2.zero;

        static class Kernels
        {
            public const int Advect = 0;
            public const int Force = 1;
            public const int PSetup = 2;
            public const int PFinish = 3;
            public const int Jacobi1 = 4;
            public const int Jacobi2 = 5;
        }

        private int _threadCountX = 0;
        private int ThreadCountX
        {
            get { return _threadCountX; }
            set
            {
                _threadCountX = (value + 7) / 8;
                ResolutionX = _threadCountX * 8;
            }
        }
        private int _threadCountY = 0;
        private int ThreadCountY
        {
            get { return _threadCountY; }
            set
            {
                _threadCountY = (value * Screen.height / Screen.width + 7) / 8;
                ResolutionY = _threadCountY * 8;
            }
        }

        private int ResolutionX { get; set; }
        private int ResolutionY { get; set; }

        private FixedPoint _dxSqr = new FixedPoint();
        private FixedPoint _dt = new FixedPoint();

        private const int _jacobiIterarations = 25;

        private int _clientIdx = 0;

        // Input Queue variables
        private int _currentStep = -1;
        private const int _delaySteps = 5;

        private List<InputData> _inputQueue = new List<InputData>();

        // Force variables
        private const int _maxForces = 10;

        private ComputeBuffer _forcesBuffer = null;
        private ForceData[] _forces = new ForceData[_maxForces];
        private Vector4[] _pourOrigins = new Vector4[_maxForces];

        // Save/Load variables
        private InputSaveLoader _inputSaveLoader = null;
        private PerformanceProfiler _performanceProfiler = null;
        private AccuracyProfiler _accuracyProfiler = null;

        // Vector field buffers
        static class VFB
        {
            public static RenderTexture V1 = null;
            public static RenderTexture V2 = null;
            public static RenderTexture V3 = null;
            public static RenderTexture P1 = null;
            public static RenderTexture P2 = null;
        }

        // Color buffers (for double buffering)
        private RenderTexture _colorRT1 = null;
        private RenderTexture _colorRT2 = null;

        private RenderTexture AllocateBuffer(int componentCount, int width = 0, int height = 0)
        {
            RenderTextureFormat format = RenderTextureFormat.ARGBHalf;
            if (componentCount == 1) format = RenderTextureFormat.RHalf;
            if (componentCount == 2) format = RenderTextureFormat.RGHalf;

            if (width == 0) width = ResolutionX;
            if (height == 0) height = ResolutionY;

            RenderTexture rt = new RenderTexture(width, height, 0, format);
            rt.enableRandomWrite = true;
            rt.Create();
            return rt;
        }

        #endregion

        #region MonoBehaviour implementation

        private void OnValidate()
        {
            // Check minimum resolution
            _resolution = Mathf.Max(_resolution, 8);
        }

        private void ValidateResolution()
        {
            // Check minimum resolution
            _resolution = Mathf.Max(_resolution, 8);

            // Update thread counts
            ThreadCountX = _resolution;
            ThreadCountY = _resolution;
        }

        private void Awake()
        {
            ValidateResolution();

            // Convert constant floating-point values to fixed-point
            _fixedViscosity = new FixedPoint(_viscosity);

            FixedPoint dx = new FixedPoint(1.0f) / ResolutionY;
            _dxSqr = dx * dx;
            _dt = new FixedPoint(Time.fixedDeltaTime);

            // Check for required components
            _inputSaveLoader = GetComponent<InputSaveLoader>();
            Assert.IsTrue(_inputSaveLoader);

            _performanceProfiler = GetComponent<PerformanceProfiler>();
            Assert.IsTrue(_performanceProfiler);

            _accuracyProfiler = GetComponent<AccuracyProfiler>();
            Assert.IsTrue(_accuracyProfiler);
        }

        private void Start()
        {
            // Initialize compute shader and shader sheet
            _shaderSheet = new Material(_shader);

            _compute.SetInt("DeltaTime", _dt.RawValue);
            _shaderSheet.SetFloat("_DeltaTime", _dt.ToFloat());

            _compute.SetInt("ForceExponent", _exponent);
            _shaderSheet.SetInt("_ForceExponent", _exponent);

            // Initialize forces buffer
            _forcesBuffer = new ComputeBuffer(_maxForces, sizeof(int) * 4);

            // Allocate buffers
            VFB.V1 = AllocateBuffer(2);
            VFB.V2 = AllocateBuffer(2);
            VFB.V3 = AllocateBuffer(2);
            VFB.P1 = AllocateBuffer(1);
            VFB.P2 = AllocateBuffer(1);

            _colorRT1 = AllocateBuffer(4, Screen.width, Screen.height);
            _colorRT2 = AllocateBuffer(4, Screen.width, Screen.height);

            Graphics.Blit(_initial, _colorRT1);

#if UNITY_IOS
            Application.targetFrameRate = 60;
#endif
        }

        private void OnDestroy()
        {
            // Destroy all textures and buffers
            Destroy(_shaderSheet);

            Destroy(VFB.V1);
            Destroy(VFB.V2);
            Destroy(VFB.V3);
            Destroy(VFB.P1);
            Destroy(VFB.P2);

            Destroy(_colorRT1);
            Destroy(_colorRT2);

            _forcesBuffer.Release();
        }

        private void FixedUpdate()
        {
            // Increase current step
            ++_currentStep;

            // Don't handle new inputs when data was loaded
            if (_inputSaveLoader.GetState() != InputSaveLoader.SaveLoadState.Loading)
            {
                // Input point
                Vector2 inputPos = new Vector2(
                    (Input.mousePosition.x - Screen.width * 0.5f) / Screen.height,
                    (Input.mousePosition.y - Screen.height * 0.5f) / Screen.height
                );

                // Check for new inputs
                if (Input.GetMouseButton(1))
                {
                    // Queue Random push input
                    QueueInput(
                        new FixedVector2(inputPos),
                        new FixedVector2(_force * 0.025f * Random.insideUnitCircle),
                        false
                    );
                }
                else if (Input.GetMouseButton(0))
                {
                    // Queue Mouse drag input
                    QueueInput(
                        new FixedVector2(inputPos),
                        new FixedVector2((inputPos - _previousInput) * _force),
                        true
                    );
                }

                _previousInput = inputPos;
            }
            else
            {
                // Get the inputs that will be queued this step
                List<InputData> inputsToQueue = _inputSaveLoader.GetQueueableInputs(_currentStep + _delaySteps);
                foreach (InputData input in inputsToQueue)
                {
                    QueueLoadedInput(input);
                }
            }

            ComputeBuffer debugOutputBuffer = new ComputeBuffer(3, sizeof(float) * 2);
            _compute.SetBuffer(Kernels.Advect, "DebugOutput", debugOutputBuffer);

            // Advection
            _compute.SetTexture(Kernels.Advect, "U_in", VFB.V1);
            _compute.SetTexture(Kernels.Advect, "W_out", VFB.V2);
            _compute.Dispatch(Kernels.Advect, ThreadCountX, ThreadCountY, 1);

            Vector2[] debugOutput = new Vector2[3];
            debugOutputBuffer.GetData(debugOutput);
            for (int i = 0; i < debugOutputBuffer.count; ++i)
            {
                if (i == 0) break;
                Debug.Log($"Advect Output[{i}] = [{debugOutput[i].x}, {debugOutput[i].y}]");
            }

            _compute.SetBuffer(Kernels.Jacobi2, "DebugOutput", debugOutputBuffer);

            // Diffuse setup
            FixedPoint dif_alpha = _dxSqr / (_fixedViscosity * _dt);
            _compute.SetInt("Alpha", dif_alpha.RawValue);
            _compute.SetInt("Beta", (dif_alpha + 4).RawValue);
            Graphics.CopyTexture(VFB.V2, VFB.V1);
            _compute.SetTexture(Kernels.Jacobi2, "B2_in", VFB.V1);

            // Jacobi iteration
            for (int i = 0; i < _jacobiIterarations; ++i)
            {
                _compute.SetTexture(Kernels.Jacobi2, "X2_in", VFB.V2);
                _compute.SetTexture(Kernels.Jacobi2, "X2_out", VFB.V3);
                _compute.Dispatch(Kernels.Jacobi2, ThreadCountX, ThreadCountY, 1);
                
                _compute.SetTexture(Kernels.Jacobi2, "X2_in", VFB.V3);
                _compute.SetTexture(Kernels.Jacobi2, "X2_out", VFB.V2);
                _compute.Dispatch(Kernels.Jacobi2, ThreadCountX, ThreadCountY, 1);
            }

            debugOutput = new Vector2[3];
            debugOutputBuffer.GetData(debugOutput);
            for (int i = 0; i < debugOutputBuffer.count; ++i)
            {
                if (i == 0) break;
                Debug.Log($"Jacobi2 Output[{i}] = [{debugOutput[i].x}, {debugOutput[i].y}]");
            }

            // Get inputs for current step
            List<InputData> inputs = GetCurrentStepInputs();

            // Add external force
            if (inputs.Count > 0)
            {
                int forceCount = 0;
                for (int i = 0; i < inputs.Count; ++i)
                {
                    _forces[forceCount++] = inputs[i].GetForceData();
                }
                _forcesBuffer.SetData(_forces, 0, 0, forceCount);

                _compute.SetBuffer(Kernels.Force, "Forces", _forcesBuffer);
                _compute.SetInt("ForceCount", forceCount);

                _compute.SetTexture(Kernels.Force, "W_in", VFB.V2);
                _compute.SetTexture(Kernels.Force, "W_out", VFB.V3);

                _compute.SetBuffer(Kernels.Force, "DebugOutput", debugOutputBuffer);

                _compute.Dispatch(Kernels.Force, ThreadCountX, ThreadCountY, 1);

                debugOutput = new Vector2[3];
                debugOutputBuffer.GetData(debugOutput);
                for (int i = 0; i < debugOutputBuffer.count; ++i)
                {
                    if (i == 0) break;
                    Debug.Log($"Force Output[{i}] = [{debugOutput[i].x}, {debugOutput[i].y}]");
                }
            }
            else
            {
                // Set in buffer for projection setup
                Graphics.CopyTexture(VFB.V2, VFB.V3);
            }

            _compute.SetBuffer(Kernels.PSetup, "DebugOutput", debugOutputBuffer);

            // Projection setup
            _compute.SetTexture(Kernels.PSetup, "W_in", VFB.V3);
            _compute.SetTexture(Kernels.PSetup, "DivW_out", VFB.V2);
            _compute.SetTexture(Kernels.PSetup, "P_out", VFB.P1);
            _compute.Dispatch(Kernels.PSetup, ThreadCountX, ThreadCountY, 1);

            debugOutput = new Vector2[3];
            debugOutputBuffer.GetData(debugOutput);
            for (int i = 0; i < debugOutputBuffer.count; ++i)
            {
                if (i == 0) break;
                Debug.Log($"PSetup Output[{i}] = [{debugOutput[i].x}, {debugOutput[i].y}]");
            }

            _compute.SetBuffer(Kernels.Jacobi1, "DebugOutput", debugOutputBuffer);

            // Jacobi iteration
            _compute.SetInt("Alpha", (-_dxSqr).RawValue);
            _compute.SetInt("Beta", new FixedPoint(4).RawValue);
            _compute.SetTexture(Kernels.Jacobi1, "B1_in", VFB.V2);

            for (int i = 0; i < _jacobiIterarations; ++i)
            {
                _compute.SetTexture(Kernels.Jacobi1, "X1_in", VFB.P1);
                _compute.SetTexture(Kernels.Jacobi1, "X1_out", VFB.P2);
                _compute.Dispatch(Kernels.Jacobi1, ThreadCountX, ThreadCountY, 1);

                _compute.SetTexture(Kernels.Jacobi1, "X1_in", VFB.P2);
                _compute.SetTexture(Kernels.Jacobi1, "X1_out", VFB.P1);
                _compute.Dispatch(Kernels.Jacobi1, ThreadCountX, ThreadCountY, 1);
            }

            debugOutput = new Vector2[3];
            debugOutputBuffer.GetData(debugOutput);
            for (int i = 0; i < debugOutputBuffer.count; ++i)
            {
                if (i == 0) break;
                Debug.Log($"Jacobi1 Output[{i}] = [{debugOutput[i].x}, {debugOutput[i].y}]");
            }

            _compute.SetBuffer(Kernels.PFinish, "DebugOutput", debugOutputBuffer);

            // Projection finish
            _compute.SetTexture(Kernels.PFinish, "W_in", VFB.V3);
            _compute.SetTexture(Kernels.PFinish, "P_in", VFB.P1);
            _compute.SetTexture(Kernels.PFinish, "U_out", VFB.V1);
            _compute.Dispatch(Kernels.PFinish, ThreadCountX, ThreadCountY, 1);

            debugOutput = new Vector2[3];
            debugOutputBuffer.GetData(debugOutput);
            for (int i = 0; i < debugOutputBuffer.count; ++i)
            {
                if (i == 0) break;
                Debug.Log($"PFinish Output[{i}] = [{debugOutput[i].x}, {debugOutput[i].y}]");
            }

            debugOutputBuffer.Release();

            // Gather pour inputs
            int pourCount = 0;
            for (int i = 0; i < inputs.Count; ++i)
            {
                if (inputs[i].IsStirInput) continue;

                _pourOrigins[pourCount++] = new Vector4(inputs[i].ForceOrigin.X.ToFloat(), inputs[i].ForceOrigin.Y.ToFloat());
            }

            // Apply the velocity field to the color buffer.
            float currTime = new FixedPoint(_dt.ToFloat() * _currentStep).ToFloat();
            _shaderSheet.SetFloat("_CurrTime", currTime);
            _shaderSheet.SetTexture("_VelocityField", VFB.V1);
            _shaderSheet.SetVectorArray("_ForceOrigins", _pourOrigins);
            _shaderSheet.SetInteger("_ForceCount", pourCount);

            RenderTexture debugTexture = new RenderTexture(_colorRT1.width, _colorRT1.height, 0, RenderTextureFormat.ARGBFloat);
            debugTexture.enableRandomWrite = true;
            debugTexture.Create();
            _shaderSheet.SetTexture("_DebugTex", debugTexture);
            RenderBuffer[] buffers = { _colorRT2.colorBuffer, debugTexture.colorBuffer };
            Graphics.SetRenderTarget(buffers, _colorRT2.depthBuffer);

            Graphics.Blit(_colorRT1, _shaderSheet, 0);
            //Graphics.Blit(_colorRT1, _colorRT2, _shaderSheet, 0);

            RenderTexture.active = debugTexture;
            Texture2D tex = new Texture2D(debugTexture.width, debugTexture.height, TextureFormat.RGBAFloat, false);
            tex.ReadPixels(new Rect(0, 0, debugTexture.width, debugTexture.height), 0, 0);
            tex.Apply();
            Color pixel = tex.GetPixel(debugTexture.width / 2, debugTexture.height / 2);
            Debug.Log($"Debug Output: {pixel.r}, {pixel.g}, {pixel.b}, {pixel.a}");
            RenderTexture.active = null;
            Destroy(debugTexture);

            // Swap the color buffers
            RenderTexture temp = _colorRT1;
            _colorRT1 = _colorRT2;
            _colorRT2 = temp;

            // Handle the performance measurement
            if (_performanceProfiler.IsMeasuring)
            {
                _performanceProfiler.MeasurePerformance();
            }

            // Handle the accuracy measurement
            if (_accuracyProfiler.IsMeasuring)
            {
                // Check if we are measuring this step
                if (_currentStep == _accuracyProfiler.SaveStep)
                {
                    _accuracyProfiler.MeasureAccuracy(VFB.V1, _colorRT1);
                }
            }
        }

        private void QueueInput(FixedVector2 forceOrigin, FixedVector2 forceVector, bool isStirInput)
        {
            // Create the input
            InputData newInput = new InputData(
                forceOrigin, forceVector,
                _currentStep + _delaySteps,
                _clientIdx,
                isStirInput
            );

            // Add the new input to the queue
            _inputQueue.Add(newInput);

            // Check if we are saving inputs
            if (_inputSaveLoader.GetState() == InputSaveLoader.SaveLoadState.Saving)
            {
                _inputSaveLoader.SaveInput(newInput);
            }
        }

        private void QueueLoadedInput(InputData input)
        {
            // Add the new input to the queue
            _inputQueue.Add(input);
        }

        private List<InputData> GetCurrentStepInputs()
        {
            // Check if there are queued inputs
            if (_inputQueue.Count == 0) return new List<InputData>();

            // Get the inputs for the current (or a previous) step
            List<InputData> inputs = _inputQueue
                .Where(input => input.ExecutionStep <= _currentStep)
                .OrderBy(input => input.ExecutionStep)
                .ThenBy(input => input.ClientIdx)
                .Take(_maxForces).ToList();

            // Remove these inputs from the queue
            _inputQueue.RemoveAll(input => inputs.Contains(input));

            return inputs;
        }

        private void OnRenderImage(RenderTexture source, RenderTexture destination)
        {
            Graphics.Blit(_colorRT1, destination, _shaderSheet, 1);
        }

        #endregion
    }
}
